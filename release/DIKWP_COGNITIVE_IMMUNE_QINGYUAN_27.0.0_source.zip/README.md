# DIKWP Active Cognitive Immune & Reality Repair / QINGYUAN 27.0.0

> Do not suppress negative emotion; suppress mechanisms that exploit emotion. Do not hide bad news; restore evidence and context. Do not label people as bad; constrain observable harmful conduct and amplification mechanisms.

QINGYUAN is an offline-first research prototype for detecting and actively weakening false claims, unverifiable pseudo-knowledge, context stripping, identity pressure, zero-sum relationship narratives, addictive interface design, vulnerable-audience exploitation, concealed sales funnels and verified real-world harm.

It explicitly protects criticism, whistleblowing, scientific counterexamples, grief, distress, victim testimony, factual bad news and requests for help.

The engine produces a ten-dimensional diagnosis instead of a single moral score: evidence integrity, context completeness, manipulation pressure, addiction pressure, interest opacity, vulnerability exploitation, relational externality, pseudo-knowledge risk, corrigibility and observed harm.

## Quick start

```bash
python -m pip install -e .
qingyuan27 demo --workspace outputs/demo
qingyuan27 analyze "Scientifically proven secret method—last chance to transform your life; buy now." --purpose sales --cue autoplay
```

Or open `release/QINGYUAN_Personal_Cognitive_Immunity_Client_27.0.0.html` in a modern browser.

QINGYUAN is an Alpha research prototype, not a fact oracle, diagnosis, legal decision, automatic takedown, sanction or payment system.
